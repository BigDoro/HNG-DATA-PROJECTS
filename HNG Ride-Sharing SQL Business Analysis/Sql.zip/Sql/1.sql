select 
	t1.distance_km,
	t2.name as driver_name,
	t3.name as rider_name,
	t1.pickup_city,
	t1.dropoff_city,
	t4.method as payment_method
from
	rides t1
join 
	drivers t2 on t1.driver_id = t2.driver_id
join 
	riders t3 on t1.rider_id = t3.rider_id
join 
	payments t4 on t1.ride_id = t4.ride_id
where 
	t4.amount > 0 
order by
	t1.distance_km desc
limit 10;