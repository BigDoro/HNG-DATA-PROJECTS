with driver_performance_metrics as (
    select
        r.driver_id,
        d.name as driver_name,
		d.rating as driver_static_rating,
        sum(case when p.amount > 0 then 1 else 0 end) as completed_rides,
        count(r.ride_id) as total_rides_attempted,
        sum(case when r.status = 'cancelled' then 1 else 0 end) 
			as total_cancelled_rides
    from
        rides r
    join
        drivers d on r.driver_id = d.driver_id
    left join
        payments p on r.ride_id = p.ride_id
    group by
        1, 2, 3
)
select
    driver_name,
    completed_rides,
    driver_static_rating,
    round((total_cancelled_rides * 100.0 / total_rides_attempted), 2) 
		as cancellation_rate_percent
from
    driver_performance_metrics
where
    completed_rides >= 30 
    and driver_static_rating >=4.5
    and (total_cancelled_rides * 100.0 / total_rides_attempted) < 5.0
order by
    completed_rides desc
limit 10;