with riders_2021 as(
	select 
		rider_id
	from
		riders
	where 
		extract(year from signup_date) = 2021
),
active_in_2024 AS (
	select distinct 
		t1.rider_id
	from 
		rides t1
	join 
		payments t2 on t1.ride_id = t2.ride_id
	where 
		t2.amount > 0
		and extract(year from t1.request_time) = 2024	
)

select 
	count(t1.rider_id) as riders_signup_2021_active_2024
from 
	riders_2021 t1
join 
	active_in_2024 t2 on t1.rider_id = t2.rider_id