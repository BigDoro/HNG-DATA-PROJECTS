with quarterly_revenue as (
    select
        extract(year from t1.request_time) as ride_year,
        extract(QUARTER from t1.request_time) as ride_quarter,
        sum(t2.amount) as total_revenue
    from
        rides t1
    join
        payments t2 on t1.ride_id = t2.ride_id
    where
        t2.amount > 0 
    group by
        1, 2
),
yoy_growth as (
    select
        curr.ride_year,
        curr.ride_quarter,
        curr.total_revenue as current_revenue,
        prev.total_revenue as previous_revenue,
        ((curr.total_revenue - prev.total_revenue) / prev.total_revenue) * 100 
			AS growth_percent
    from
        quarterly_revenue curr
    join
        quarterly_revenue prev
        on curr.ride_quarter = prev.ride_quarter  
        and curr.ride_year = prev.ride_year + 1   
)
select
    ride_year,
    ride_quarter,
    growth_percent
from
    yoy_growth
order by
    growth_percent desc;