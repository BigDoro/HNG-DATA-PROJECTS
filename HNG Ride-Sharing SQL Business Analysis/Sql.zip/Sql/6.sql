with rider_payment_summary as (
    select
        t1.rider_id,
        t2.name as rider_name,
        count(t1.ride_id) as total_completed_rides,
        sum(case when t3.method = 'cash' then 1 else 0 end) as cash_payments_count
    from
        rides t1
    join
        riders t2 on t1.rider_id = t2.rider_id
    join
        payments t3 on t1.ride_id = t3.ride_id
    where
        t3.amount > 0 
    group by
        t1.rider_id, t2.name
)
select
    rider_name,
    total_completed_rides,
    cash_payments_count 
from
    rider_payment_summary
where
    total_completed_rides > 10  
    and cash_payments_count = 0 
order by
    total_completed_rides desc;