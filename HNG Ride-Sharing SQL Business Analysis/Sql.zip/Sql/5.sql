with city_ride_metrics as (
    select
        pickup_city,
        count(ride_id) as total_rides_attempted,
        sum(case when status = 'cancelled' then 1 else 0 end) 
			as total_cancelled_rides
    from
        rides
    where
        pickup_city is not null 
    group by
        pickup_city
)
select
    pickup_city,
    total_rides_attempted,
    total_cancelled_rides,
    (total_cancelled_rides * 100.0 / total_rides_attempted) 
		as cancellation_rate_percent
from
    city_ride_metrics
where
    total_rides_attempted > 0 
order by
    cancellation_rate_percent desc; 