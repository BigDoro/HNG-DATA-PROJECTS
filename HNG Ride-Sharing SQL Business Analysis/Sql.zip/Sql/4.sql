with driver_ride_summary as(
	select 
		t1.driver_id,
		t2.name as driver_name,
		t2.signup_date,
		count(t1.ride_id) as total_rides,
		max (t1.request_time) as last_ride_time
	from
		rides t1
	join 
		drivers t2 on t1.driver_id = t2.driver_id
	join 
		payments t3 on t1.ride_id = t3.ride_id
	where
		t3.amount > 0
	group by 
		t1.driver_id, t2.name, t2.signup_date
),
driver_consistency as (
	select 
		driver_name,
		total_rides,
		(extract(year from last_ride_time) - extract(year from signup_date)) * 12 +
		(extract(month from last_ride_time) - extract(month from signup_date)) + 1
		as active_months,
		(total_rides * 1.0 / (
			(extract(year from last_ride_time) - extract(year from signup_date)) * 12+
			(extract(month from last_ride_time) - extract(month from signup_date))+1
		)) as average_monthly_rides
	from 
		driver_ride_summary
	where
		(extract (year from last_ride_time) - extract(year from signup_date)) * 12 +
		(extract(month from last_ride_time) - extract(month from signup_date))+ 1 > 0
)
select 
	driver_name,
	total_rides,
	active_months,
	round(average_monthly_rides, 2) as avg_monthly_rides_per_active_month
from
	driver_consistency
order by
	average_monthly_rides desc
limit 5;		
		
