with city_driver_revenue as (
    select
        r.pickup_city,
        d.name as driver_name,
        sum(p.amount) as total_revenue,
        rank() over (partition by r.pickup_city order by sum(p.amount) desc) 
			as city_rank
    from
        rides r
    join
        drivers d on r.driver_id = d.driver_id
    join
        payments p on r.ride_id = p.ride_id
    where
        p.amount > 0 
    group by
        1, 2
)
select
    pickup_city,
    driver_name,
    total_revenue
from
    city_driver_revenue
where
    city_rank <= 3 
order by
    pickup_city, total_revenue desc;